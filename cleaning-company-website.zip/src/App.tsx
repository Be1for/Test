import { useState } from "react";

const img = (id: number, w = 1200, h = 800) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=${h}&w=${w}`;

const services = [
  { icon: "🏠", title: "Поддерживающая уборка", desc: "Регулярная уборка квартир и домов: пыль, полы, санузлы, кухня.", price: "от 2 500 ₽" },
  { icon: "✨", title: "Генеральная уборка", desc: "Глубокая чистка всех поверхностей, включая труднодоступные места.", price: "от 5 900 ₽" },
  { icon: "🛠️", title: "После ремонта", desc: "Удаляем строительную пыль, следы краски, штукатурки и затирки.", price: "от 7 500 ₽" },
  { icon: "🏢", title: "Уборка офисов", desc: "Ежедневная и разовая уборка офисов, магазинов и студий.", price: "от 90 ₽/м²" },
  { icon: "🪟", title: "Мытьё окон", desc: "Окна, балконы и витрины без разводов — снаружи и изнутри.", price: "от 300 ₽/окно" },
  { icon: "🛋️", title: "Химчистка мебели", desc: "Диваны, матрасы, ковры: убираем пятна и неприятные запахи.", price: "от 1 800 ₽" },
];

const steps = [
  { n: "01", t: "Оставляете заявку", d: "По телефону или через форму — ответим за 10 минут." },
  { n: "02", t: "Рассчитываем стоимость", d: "Фиксированная цена без скрытых доплат." },
  { n: "03", t: "Приезжает бригада", d: "Со своим оборудованием и профессиональной химией." },
  { n: "04", t: "Принимаете работу", d: "Не понравилось — переделаем бесплатно." },
];

const reviews = [
  { name: "Анна К.", role: "Квартира, Москва", text: "Заказывала генеральную уборку перед праздниками. Девочки приехали вовремя, всё блестит! Теперь только к вам." },
  { name: "Дмитрий С.", role: "Директор IT-студии", text: "Офис убирают по ночам — утром всегда чисто. Работаем уже второй год, ни одного нарекания." },
  { name: "Елена М.", role: "После ремонта", text: "Думала, строительную пыль не победить. Справились за один день, даже окна отмыли от краски." },
];

const faqs = [
  { q: "Нужно ли мне покупать моющие средства?", a: "Нет. Мы привозим всё необходимое: профессиональную химию, пылесосы, моющие пылесосы и инвентарь." },
  { q: "Безопасна ли ваша химия для детей и животных?", a: "Да, мы используем гипоаллергенные сертифицированные средства. По запросу — полностью эко-линейку." },
  { q: "Что если результат мне не понравится?", a: "Сообщите в течение 24 часов — мы бесплатно приедем и переделаем всё, что вас не устроило." },
  { q: "Можно ли заказать уборку на сегодня?", a: "Да, при наличии свободных бригад выезжаем в течение 3 часов. Уточняйте по телефону." },
];

function Calculator() {
  const [area, setArea] = useState(55);
  const [type, setType] = useState(0);
  const [extras, setExtras] = useState<number[]>([]);
  const types = [
    { n: "Поддерживающая", rate: 60 },
    { n: "Генеральная", rate: 110 },
    { n: "После ремонта", rate: 150 },
  ];
  const opts = [
    { n: "Мытьё окон", p: 1200 },
    { n: "Химчистка дивана", p: 2200 },
    { n: "Чистка духовки и холодильника", p: 900 },
    { n: "Глажка белья", p: 700 },
  ];
  const total = Math.max(2500, area * types[type].rate) + extras.reduce((s, i) => s + opts[i].p, 0);
  const toggle = (i: number) => setExtras((e) => (e.includes(i) ? e.filter((x) => x !== i) : [...e, i]));

  return (
    <div className="grid lg:grid-cols-5 gap-8 bg-white rounded-3xl shadow-xl shadow-teal-900/5 p-6 md:p-10 border border-slate-100">
      <div className="lg:col-span-3 space-y-8">
        <div>
          <div className="flex justify-between mb-3">
            <label className="font-semibold text-slate-800">Площадь помещения</label>
            <span className="font-bold text-teal-600">{area} м²</span>
          </div>
          <input type="range" min={20} max={300} value={area} onChange={(e) => setArea(+e.target.value)} className="w-full accent-teal-500" />
        </div>
        <div>
          <p className="font-semibold text-slate-800 mb-3">Тип уборки</p>
          <div className="grid sm:grid-cols-3 gap-3">
            {types.map((t, i) => (
              <button key={t.n} onClick={() => setType(i)} className={`rounded-xl px-4 py-3 text-sm font-medium border transition ${type === i ? "bg-teal-500 text-white border-teal-500 shadow-md" : "bg-slate-50 border-slate-200 text-slate-700 hover:border-teal-400"}`}>
                {t.n}
              </button>
            ))}
          </div>
        </div>
        <div>
          <p className="font-semibold text-slate-800 mb-3">Дополнительно</p>
          <div className="grid sm:grid-cols-2 gap-3">
            {opts.map((o, i) => (
              <label key={o.n} className={`flex items-center gap-3 rounded-xl px-4 py-3 border cursor-pointer text-sm transition ${extras.includes(i) ? "border-teal-500 bg-teal-50" : "border-slate-200 hover:border-teal-300"}`}>
                <input type="checkbox" checked={extras.includes(i)} onChange={() => toggle(i)} className="accent-teal-500 w-4 h-4" />
                <span className="flex-1 text-slate-700">{o.n}</span>
                <span className="text-slate-500">+{o.p} ₽</span>
              </label>
            ))}
          </div>
        </div>
      </div>
      <div className="lg:col-span-2 rounded-2xl bg-gradient-to-br from-teal-500 to-cyan-600 text-white p-8 flex flex-col justify-between">
        <div>
          <p className="text-teal-100 text-sm">Примерная стоимость</p>
          <p className="text-5xl font-extrabold mt-2">{total.toLocaleString("ru-RU")} ₽</p>
          <ul className="mt-6 space-y-2 text-sm text-teal-50">
            <li>✓ Оборудование и химия включены</li>
            <li>✓ Фиксированная цена в договоре</li>
            <li>✓ Гарантия качества 24 часа</li>
          </ul>
        </div>
        <a href="#contact" className="mt-8 block text-center bg-white text-teal-700 font-bold rounded-xl py-3.5 hover:bg-teal-50 transition">
          Заказать по этой цене
        </a>
      </div>
    </div>
  );
}

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <div className="space-y-3">
      {faqs.map((f, i) => (
        <div key={f.q} className="bg-white rounded-2xl border border-slate-100 overflow-hidden">
          <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex justify-between items-center gap-4 text-left px-6 py-5 font-semibold text-slate-800">
            {f.q}
            <span className={`text-teal-500 text-2xl transition-transform ${open === i ? "rotate-45" : ""}`}>+</span>
          </button>
          {open === i && <p className="px-6 pb-5 text-slate-600">{f.a}</p>}
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [sent, setSent] = useState(false);
  const [menu, setMenu] = useState(false);
  const links = [
    ["Услуги", "#services"],
    ["Калькулятор", "#calc"],
    ["Как мы работаем", "#steps"],
    ["Отзывы", "#reviews"],
    ["Контакты", "#contact"],
  ];

  return (
    <div className="font-sans text-slate-700 bg-slate-50 scroll-smooth">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/85 backdrop-blur border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-5 h-16 flex items-center justify-between">
          <a href="#" className="flex items-center gap-2 font-extrabold text-xl text-slate-900">
            <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-teal-400 to-cyan-500 grid place-items-center text-white">✦</span>
            Чисто<span className="text-teal-500">Дом</span>
          </a>
          <nav className="hidden md:flex gap-7 text-sm font-medium">
            {links.map(([t, h]) => (
              <a key={h} href={h} className="hover:text-teal-600 transition">{t}</a>
            ))}
          </nav>
          <div className="hidden md:flex items-center gap-4">
            <a href="tel:+78005553535" className="font-bold text-slate-900">8 800 555-35-35</a>
            <a href="#contact" className="bg-teal-500 hover:bg-teal-600 text-white text-sm font-semibold px-5 py-2.5 rounded-xl transition">Заказать</a>
          </div>
          <button className="md:hidden text-2xl" onClick={() => setMenu(!menu)} aria-label="Меню">{menu ? "✕" : "☰"}</button>
        </div>
        {menu && (
          <div className="md:hidden px-5 pb-5 flex flex-col gap-3 bg-white">
            {links.map(([t, h]) => (
              <a key={h} href={h} onClick={() => setMenu(false)} className="py-1 font-medium">{t}</a>
            ))}
            <a href="tel:+78005553535" className="font-bold text-teal-600">8 800 555-35-35</a>
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-teal-50 to-slate-50">
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-cyan-200/40 rounded-full blur-3xl" />
        <div className="max-w-7xl mx-auto px-5 py-16 md:py-24 grid lg:grid-cols-2 gap-12 items-center relative">
          <div>
            <span className="inline-flex items-center gap-2 bg-white border border-teal-100 text-teal-700 text-sm font-medium px-4 py-1.5 rounded-full shadow-sm">
              <span className="w-2 h-2 bg-teal-500 rounded-full animate-pulse" /> Выезжаем в день обращения
            </span>
            <h1 className="mt-6 text-4xl md:text-6xl font-extrabold text-slate-900 leading-tight">
              Идеальная чистота <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-500 to-cyan-600">без вашего участия</span>
            </h1>
            <p className="mt-6 text-lg text-slate-600 max-w-xl">
              Профессиональная уборка квартир, домов и офисов. Проверенные специалисты, экологичная химия и гарантия результата.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a href="#calc" className="bg-teal-500 hover:bg-teal-600 text-white font-semibold px-8 py-4 rounded-2xl shadow-lg shadow-teal-500/30 transition">Рассчитать стоимость</a>
              <a href="#services" className="bg-white hover:bg-slate-100 text-slate-800 font-semibold px-8 py-4 rounded-2xl border border-slate-200 transition">Наши услуги</a>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-6 max-w-md">
              {[["8+", "лет на рынке"], ["12 000", "уборок"], ["4.9", "рейтинг"]].map(([a, b]) => (
                <div key={b}>
                  <p className="text-3xl font-extrabold text-slate-900">{a}</p>
                  <p className="text-sm text-slate-500">{b}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <img src={img(6195274)} alt="Клинеры убирают гостиную" className="rounded-3xl shadow-2xl w-full h-[420px] md:h-[520px] object-cover" />
            <div className="absolute -bottom-6 -left-4 md:-left-8 bg-white rounded-2xl shadow-xl p-4 flex items-center gap-3">
              <span className="w-12 h-12 rounded-full bg-emerald-100 grid place-items-center text-2xl">🛡️</span>
              <div>
                <p className="font-bold text-slate-900">Гарантия 24 часа</p>
                <p className="text-sm text-slate-500">Переделаем бесплатно</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Advantages */}
      <section className="max-w-7xl mx-auto px-5 py-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {[
          ["🌿", "Эко-химия", "Безопасно для детей и питомцев"],
          ["👩‍🔧", "Проверенный персонал", "Обучение и проверка документов"],
          ["📄", "Договор и чек", "Фиксированная цена без доплат"],
          ["⏱️", "Точно в срок", "Приезжаем в согласованное время"],
        ].map(([i, t, d]) => (
          <div key={t} className="bg-white rounded-2xl p-6 border border-slate-100 hover:shadow-lg transition">
            <div className="text-3xl">{i}</div>
            <h3 className="mt-3 font-bold text-slate-900">{t}</h3>
            <p className="text-sm text-slate-500 mt-1">{d}</p>
          </div>
        ))}
      </section>

      {/* Services */}
      <section id="services" className="max-w-7xl mx-auto px-5 py-20">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-teal-600 font-semibold">Услуги</p>
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mt-2">Что мы убираем</h2>
          <p className="mt-4 text-slate-600">Подберём формат уборки под ваши задачи и бюджет.</p>
        </div>
        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((s) => (
            <div key={s.title} className="group bg-white rounded-3xl p-8 border border-slate-100 hover:border-teal-300 hover:-translate-y-1 hover:shadow-xl transition-all">
              <div className="w-14 h-14 rounded-2xl bg-teal-50 group-hover:bg-teal-500 transition grid place-items-center text-3xl">{s.icon}</div>
              <h3 className="mt-5 text-xl font-bold text-slate-900">{s.title}</h3>
              <p className="mt-2 text-slate-600">{s.desc}</p>
              <p className="mt-5 font-bold text-teal-600">{s.price}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Calculator */}
      <section id="calc" className="bg-gradient-to-b from-slate-50 to-teal-50/60 py-20">
        <div className="max-w-6xl mx-auto px-5">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <p className="text-teal-600 font-semibold">Калькулятор</p>
            <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mt-2">Узнайте стоимость за минуту</h2>
          </div>
          <Calculator />
        </div>
      </section>

      {/* Before / team */}
      <section className="max-w-7xl mx-auto px-5 py-20 grid lg:grid-cols-2 gap-12 items-center">
        <div className="grid grid-cols-2 gap-4">
          <img src={img(6195129, 600, 800)} alt="Команда клинеров" className="rounded-3xl h-72 w-full object-cover" />
          <img src={img(6195949, 600, 800)} alt="Пылесос" className="rounded-3xl h-72 w-full object-cover mt-10" />
        </div>
        <div>
          <p className="text-teal-600 font-semibold">О компании</p>
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mt-2">Команда, которой доверяют свой дом</h2>
          <p className="mt-5 text-slate-600">
            «ЧистоДом» — это более 60 обученных специалистов, собственный склад оборудования и строгий контроль качества. Каждый клинер проходит проверку и стажировку, а после уборки наш менеджер связывается с вами и уточняет результат.
          </p>
          <ul className="mt-6 space-y-3">
            {["Профессиональное оборудование Karcher и Numatic", "Сертифицированная гипоаллергенная химия", "Страхование имущества клиентов до 1 000 000 ₽"].map((t) => (
              <li key={t} className="flex gap-3 items-start">
                <span className="mt-1 w-5 h-5 rounded-full bg-teal-500 text-white text-xs grid place-items-center shrink-0">✓</span>
                {t}
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Steps */}
      <section id="steps" className="bg-slate-900 py-20 text-white">
        <div className="max-w-7xl mx-auto px-5">
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-teal-400 font-semibold">Как мы работаем</p>
            <h2 className="text-3xl md:text-4xl font-extrabold mt-2">Четыре простых шага</h2>
          </div>
          <div className="mt-12 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((s) => (
              <div key={s.n} className="rounded-3xl bg-white/5 border border-white/10 p-7">
                <p className="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-br from-teal-300 to-cyan-500">{s.n}</p>
                <h3 className="mt-4 text-lg font-bold">{s.t}</h3>
                <p className="mt-2 text-slate-300 text-sm">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section id="reviews" className="max-w-7xl mx-auto px-5 py-20">
        <div className="text-center max-w-2xl mx-auto">
          <p className="text-teal-600 font-semibold">Отзывы</p>
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 mt-2">Нас рекомендуют клиенты</h2>
        </div>
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          {reviews.map((r) => (
            <figure key={r.name} className="bg-white rounded-3xl p-8 border border-slate-100 shadow-sm">
              <div className="text-amber-400 text-lg">★★★★★</div>
              <blockquote className="mt-4 text-slate-700">«{r.text}»</blockquote>
              <figcaption className="mt-6 flex items-center gap-3">
                <span className="w-11 h-11 rounded-full bg-gradient-to-br from-teal-400 to-cyan-500 text-white font-bold grid place-items-center">{r.name[0]}</span>
                <span>
                  <span className="block font-bold text-slate-900">{r.name}</span>
                  <span className="text-sm text-slate-500">{r.role}</span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="max-w-3xl mx-auto px-5 pb-20">
        <h2 className="text-3xl font-extrabold text-slate-900 text-center mb-10">Частые вопросы</h2>
        <Faq />
      </section>

      {/* Contact */}
      <section id="contact" className="px-5 pb-20">
        <div className="max-w-6xl mx-auto rounded-3xl bg-gradient-to-br from-teal-500 to-cyan-600 p-8 md:p-14 grid lg:grid-cols-2 gap-10 text-white">
          <div>
            <h2 className="text-3xl md:text-4xl font-extrabold">Закажите уборку сегодня</h2>
            <p className="mt-4 text-teal-50">Оставьте контакты — перезвоним в течение 10 минут и рассчитаем точную стоимость. Скидка 10% на первый заказ!</p>
            <div className="mt-8 space-y-3 text-teal-50">
              <p>📞 8 800 555-35-35</p>
              <p>✉️ hello@chistodom.ru</p>
              <p>📍 Москва, ул. Чистая, 12</p>
              <p>🕒 Ежедневно, 8:00 – 22:00</p>
            </div>
          </div>
          {sent ? (
            <div className="bg-white rounded-2xl p-10 text-slate-800 grid place-items-center text-center">
              <div>
                <div className="text-5xl">🎉</div>
                <h3 className="mt-4 text-2xl font-bold">Спасибо за заявку!</h3>
                <p className="mt-2 text-slate-600">Мы свяжемся с вами в ближайшее время.</p>
              </div>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSent(true);
              }}
              className="bg-white rounded-2xl p-6 md:p-8 space-y-4 text-slate-800"
            >
              <input required placeholder="Ваше имя" className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100" />
              <input required type="tel" placeholder="Телефон" className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100" />
              <select className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-teal-500 bg-white text-slate-600">
                {services.map((s) => (
                  <option key={s.title}>{s.title}</option>
                ))}
              </select>
              <textarea rows={3} placeholder="Комментарий (необязательно)" className="w-full rounded-xl border border-slate-200 px-4 py-3 outline-none focus:border-teal-500 focus:ring-2 focus:ring-teal-100" />
              <button className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 rounded-xl transition">Отправить заявку</button>
              <p className="text-xs text-slate-400 text-center">Нажимая кнопку, вы соглашаетесь с политикой конфиденциальности</p>
            </form>
          )}
        </div>
      </section>

      <footer className="border-t border-slate-200 bg-white py-8 text-center text-sm text-slate-500">
        © {new Date().getFullYear()} ЧистоДом — клининговая компания. Все права защищены.
      </footer>
    </div>
  );
}
